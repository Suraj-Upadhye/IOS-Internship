//
//  ViewController.swift
//  Rainbow
//
//  Created by Apple Lab 2 on 03/01/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


