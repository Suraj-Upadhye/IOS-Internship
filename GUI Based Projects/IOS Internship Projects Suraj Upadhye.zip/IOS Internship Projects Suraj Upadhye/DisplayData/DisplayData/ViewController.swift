//
//  ViewController.swift
//  DisplayData
//
//  Created by Apple Lab 20 on 30/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

